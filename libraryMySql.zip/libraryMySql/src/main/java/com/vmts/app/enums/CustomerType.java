package com.vmts.app.enums;

public enum CustomerType {
	PRIVATE, GOVT;
}
