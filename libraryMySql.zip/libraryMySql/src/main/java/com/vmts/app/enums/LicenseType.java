package com.vmts.app.enums;

public enum LicenseType {
	LMV,HMV
}
