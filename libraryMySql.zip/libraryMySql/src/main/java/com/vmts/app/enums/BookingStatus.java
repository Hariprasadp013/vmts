package com.vmts.app.enums;

public enum BookingStatus {
	BOOKED,CONFIRMED,CANCELLED,COMPLETED,PAID
}
