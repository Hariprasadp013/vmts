package com.vmts.app.enums;

public enum VehicleType {
	LMV,HMV;
}
