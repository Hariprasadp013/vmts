package com.library.demo.service;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class BookServiceTest {
	@Test
	public void test() {
		assertEquals(Boolean.TRUE, false);
	}
}
